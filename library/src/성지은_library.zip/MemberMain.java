package library;
import java.util.*;

public class MemberMain {
	public static void main(String[] args) {
		LoginGUI gui = new LoginGUI("�α���");
	}
}
