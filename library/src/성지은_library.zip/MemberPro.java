package library;

public interface MemberPro {
	public int insert(Member mb);
	public int search(Member mb);
	public Member view(String id);
}
